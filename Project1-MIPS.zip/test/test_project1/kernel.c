#define printstraddr  0xffffffff8f0d5534 
#define printchaddr 0xffffffff8f0d5570
#define state_r  0xffffffffbfe00005
#define data_r 0xffffffffbfe00000
void (*printstr)(char* str);
void (*printch)(char ch);
void __attribute__((section(".entry_function"))) _start(void)
{
    printstr = (void*)printstraddr;
    printch = (void*)printchaddr;
    char *msg = "Hello OS!!";
    (*printstr)(msg);
    (*printstr)(msg);
    (*printstr)(msg);
    (*printstr)(msg);
    (*printstr)(msg);
    (*printstr)(msg);
    (*printstr)(msg);
    (*printstr)(msg);
    (*printstr)(msg);
    (*printstr)(msg);
    (*printstr)(msg);
    (*printstr)(msg);
    (*printstr)(msg);
    (*printstr)(msg);
    (*printstr)(msg);
    (*printstr)(msg);
    (*printstr)(msg);
    (*printstr)(msg);
    (*printstr)(msg);
    (*printstr)(msg);
    (*printstr)(msg);
    (*printstr)(msg);
    (*printstr)(msg);
    (*printstr)(msg);
    (*printstr)(msg);
    (*printstr)(msg);
    (*printstr)(msg);
    (*printstr)(msg)；
    while(1){
        if(*((char*)state_r)&0x01){
            (*printch)(*((char*)data_r));
        }
    }
}
