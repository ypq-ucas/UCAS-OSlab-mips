#ifndef INCLUDE_TASK4_H_
#define INCLUDE_TASK4_H_

#include "type.h"

void drawing_task1(void);
void rw_task1(char *argv[]);

#endif
