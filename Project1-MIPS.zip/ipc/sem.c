#include "sem.h"
#include "stdio.h"

void do_semaphore_init(semaphore_t *s, int val)
{
    
}

void do_semaphore_up(semaphore_t *s)
{
     
}

void do_semaphore_down(semaphore_t *s)
{
    
}