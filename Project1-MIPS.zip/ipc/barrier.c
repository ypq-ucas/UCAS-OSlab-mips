#include "barrier.h"

void do_barrier_init(barrier_t *barrier, int goal)
{
     
}

void do_barrier_wait(barrier_t *barrier)
{
    
}