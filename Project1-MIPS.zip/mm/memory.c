#include "mm.h"

void init_page_table()
{
}
void do_TLB_Refill()
{
}

void do_page_fault()
{
}
void init_TLB(void)
{
}
void physical_frame_initial(void)
{
}